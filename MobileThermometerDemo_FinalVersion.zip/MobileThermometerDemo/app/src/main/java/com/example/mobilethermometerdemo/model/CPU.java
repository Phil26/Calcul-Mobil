package com.example.mobilethermometerdemo.model;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class CPU {
    public static int getCPUTempHTC() {
        if (new File("/sys/htc/cpu_temp").exists()) {
            int readSystemFileAsInt = readSystemFileAsInt("/sys/htc/cpu_temp");
            if (readSystemFileAsInt > 3) {
                return readSystemFileAsInt;
            }
        }
        return 0;
    }

    public static int getCPUTempTegra() {
        if (new File("/sys/kernel/debug/tegra_thermal/temp_tj").exists()) {
            int readSystemFileAsInt = readSystemFileAsInt("/sys/kernel/debug/tegra_thermal/temp_tj");
            if (readSystemFileAsInt > 3) {
                return readSystemFileAsInt;
            }
        }
        return 0;
    }

    public static int getCPUTemperature() {
        int readSystemFileAsInt;
        File file = new File("/sys/kernel/debug/tegra_thermal/temp_tj");
        File file2 = new File("/sys/htc/cpu_temp");
        File file3 = new File("/sys/devices/virtual/thermal/thermal_zone0/temp");
        File file4 = new File("/sys/devices/platform/s5p-tmu/temperature");
        if (file.exists()) {
            int readSystemFileAsInt2 = readSystemFileAsInt("/sys/kernel/debug/tegra_thermal/temp_tj");
            if (readSystemFileAsInt2 > 0) {
                if (readSystemFileAsInt2 > 1000) {
                    readSystemFileAsInt2 /= 1000;
                }
                return readSystemFileAsInt2;
            }
        }
        if (file2.exists() && !file.exists()) {
            int readSystemFileAsInt3 = readSystemFileAsInt("/sys/htc/cpu_temp");
            if (readSystemFileAsInt3 > 3) {
                return readSystemFileAsInt3;
            }
        }
        if (file3.exists() && !file.exists()) {
            readSystemFileAsInt = readSystemFileAsInt("/sys/devices/virtual/thermal/thermal_zone0/temp");
            if (readSystemFileAsInt > 3) {
                if (readSystemFileAsInt > 1000) {
                    readSystemFileAsInt /= 1000;
                }
                return readSystemFileAsInt;
            }
        }
        if (file4.exists()) {
            readSystemFileAsInt = readSystemFileAsInt("/sys/devices/platform/s5p-tmu/temperature");
            if (readSystemFileAsInt > 3) {
                if (readSystemFileAsInt > 1000) {
                    readSystemFileAsInt /= 1000;
                }
                return readSystemFileAsInt;
            }
        }
        return -1;
    }

    public static int readSystemFileAsInt(String str) {
        try {
            return Integer.parseInt(readFully(new ProcessBuilder(new String[]{"/system/bin/cat", str}).start().getInputStream()));
        } catch (Exception unused) {
            return -1;
        }
    }

    public static String readFully(InputStream inputStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        Scanner scanner = new Scanner(inputStream);
        while (scanner.hasNextLine()) {
            stringBuilder.append(scanner.nextLine());
        }
        return stringBuilder.toString();
    }
}
