package com.example.mobilethermometerdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BatteryActivity extends AppCompatActivity {
    private Button back1;
    ImageView img;
    TextView BatTemp;
    BroadcastReceiver batteryBroadcast = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery);
        back1 = (Button) findViewById(R.id.back1);
        back1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openMainActivity();
            }
        });
        img = findViewById(R.id.img);
        img.setImageResource(R.drawable.ic_battery);
        BatTemp = (TextView) findViewById(R.id.Temperature);
        intentFilterAndBroadcast();
    }

    private void intentFilterAndBroadcast(){
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        batteryBroadcast = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction()))
                {
                    float temp = (float) intent.getIntExtra("BatTemp", -1) / 10;
                    BatTemp.setText(String.valueOf(temp));
                }
            }
        };
    }

    public void openMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}