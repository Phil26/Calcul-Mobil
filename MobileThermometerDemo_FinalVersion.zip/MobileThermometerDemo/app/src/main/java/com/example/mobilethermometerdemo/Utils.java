package com.example.mobilethermometerdemo;

import android.app.Dialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import java.util.Random;

public class Utils {
    public static final int DEFAULT_SOURCE = 1;
    public static final boolean IS_CELSIUS_DEFAULT = true;
    public static final String SOURCE_KEY = "SourceKey";
    public static final String UNIT_KEY = "UnitKey";

    public static float celsiusToFarenheit(float f) {
        return (f * 1.8f) + 32.0f;
    }

    public static float farenheitToCelsius(float f) {
        return ((f - 32.0f) * 5.0f) / 9.0f;
    }
    public static final Random RANDOM = new Random();

    public static void storeSourceKey(Context context, int i) {
        if (context != null) {
            PreferenceManager.getDefaultSharedPreferences(context).edit().putInt(SOURCE_KEY, i).commit();
        }
    }

    public static int sourceKey(Context context) {
        return context != null ? PreferenceManager.getDefaultSharedPreferences(context).getInt(SOURCE_KEY, 1) : 1;
    }

    public static float convertDpToPixel(float f, Context context) {
        return f * (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }

    public static float convertPixelsToDp(float f, Context context) {
        return f / (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }

    public static void closeDialog(Dialog dialog) {
        try {
            dialog.dismiss();
        } catch (Exception unused) {
        }
    }

    public static boolean isCelsiusUnit(Context context) {
        return context != null ? getPreferenceValue(UNIT_KEY, true, context) : true;
    }

    public static void savePreferenceValue(String str, boolean z, Context context) {
        if (str != null && context != null) {
            PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(str, z).commit();
        }
    }

    public static boolean getPreferenceValue(String str, boolean z, Context context) {
        return (str == null || context == null) ? z : PreferenceManager.getDefaultSharedPreferences(context).getBoolean(str, z);
    }

    public static boolean isConnected(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    public static int randInt(int min, int max){
        int randomNum = RANDOM.nextInt((max - min) + 1) + min;
        return randomNum;
    }
}
